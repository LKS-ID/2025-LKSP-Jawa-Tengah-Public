import torch
from torchvision import transforms
from PIL import Image

model = torch.load("restnet.pt")
model.eval()

image = Image.open("image.jpg").convert("RGB")

transform = transforms.Compose([
    transforms.Resize(256),
    transforms.CenterCrop(224),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406],std=[0.229, 0.224, 0.225])
])

its = transform(image).unsqueeze(0)
with torch.no_grad():
    output = model(its)
    predicted_idx = output.argmax(dim=1).item()

print(f"Predicted class index -> {predicted_idx}")