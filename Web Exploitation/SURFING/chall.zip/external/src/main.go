package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"text/template"
	"time"
)

// Ticket represents a surfing ticket
type Ticket struct {
	ID        string    `json:"id"`
	UserID    string    `json:"user_id"`
	Date      time.Time `json:"date"`
	Status    string    `json:"status"`
	CreatedAt time.Time `json:"created_at"`
}

// User represents a user
type User struct {
	ID       string `json:"id"`
	Username string `json:"username"`
	Email    string `json:"email"`
}

// TemplateData holds data for the templates
type TemplateData struct {
	Title              string
	Ticket             *TicketDisplay
	Tickets            []Ticket
	Error              string
}

// TicketDisplay adds formatted date strings to Ticket for display
type TicketDisplay struct {
	ID                 string
	UserID             string
	Date               time.Time
	DateFormatted      string
	Status             string
	CreatedAt          time.Time
	CreatedAtFormatted string
}

// In-memory storage for tickets and users
var (
	tickets   = make(map[string]Ticket)
	users     = make(map[string]User)
	templates = make(map[string]*template.Template)
)

const (
	port = ":8080"
)

func init() {
	// Load templates
	templates["home"] = template.Must(template.ParseFiles("templates/layout.html", "templates/home.html"))
	templates["buy"] = template.Must(template.ParseFiles("templates/layout.html", "templates/buy.html"))
	templates["status"] = template.Must(template.ParseFiles("templates/layout.html", "templates/status.html"))
	templates["ticket_details"] = template.Must(template.ParseFiles("templates/layout.html", "templates/ticket_details.html"))
}

func main() {
	// Check if templates directory exists
	if _, err := os.Stat("templates"); os.IsNotExist(err) {
		log.Println("Warning: templates directory not found")
	}

	// Check if static directory exists
	if _, err := os.Stat("static"); os.IsNotExist(err) {
		log.Println("Warning: static directory not found")
	}

	// Initialize some sample data
	initializeData()

	// Serve static files
	http.Handle("/static/", http.StripPrefix("/static/", http.FileServer(http.Dir("static"))))

	// Routes
	http.HandleFunc("/", handleHome)
	http.HandleFunc("/buy", handleBuyTicket)
	http.HandleFunc("/status", handleTicketStatus)
	http.HandleFunc("/api/tickets", handleTicketsAPI)
	http.HandleFunc("/api/check-status", handleCheckStatusAPI)

	log.Printf("External service starting on port %s\n", port)
	log.Fatal(http.ListenAndServe(port, nil))
}

func initializeData() {
	// Add a sample user
	users["user1"] = User{
		ID:       "user1",
		Username: "surfer123",
		Email:    "surfer@example.com",
	}

	// Add a sample ticket
	tickets["ticket1"] = Ticket{
		ID:        "ticket1",
		UserID:    "user1",
		Date:      time.Now().AddDate(0, 0, 7), // 7 days from now
		Status:    "confirmed",
		CreatedAt: time.Now(),
	}
}

func handleHome(w http.ResponseWriter, r *http.Request) {
	data := TemplateData{
		Title: "Surfing Ticket Service",
	}
	
	renderTemplate(w, "home", data)
}

func handleBuyTicket(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		// Process ticket purchase
		userID := r.FormValue("user_id")
		dateStr := r.FormValue("date")
		
		// Parse date
		date, err := time.Parse("2006-01-02", dateStr)
		if err != nil {
			http.Error(w, "Invalid date format", http.StatusBadRequest)
			return
		}
		
		// Generate ticket ID
		ticketID := fmt.Sprintf("ticket%d", len(tickets)+1)
		
		// Create new ticket
		ticket := Ticket{
			ID:        ticketID,
			UserID:    userID,
			Date:      date,
			Status:    "pending",
			CreatedAt: time.Now(),
		}
		
		// Save ticket
		tickets[ticketID] = ticket
		
		// Redirect to status page
		http.Redirect(w, r, "/status?ticket_id="+ticketID, http.StatusSeeOther)
		return
	}
	
	// Display buy ticket form
	data := TemplateData{
		Title: "Buy Surfing Ticket",
	}
	
	renderTemplate(w, "buy", data)
}

func handleTicketStatus(w http.ResponseWriter, r *http.Request) {
	ticketID := r.URL.Query().Get("ticket_id")
	
	if ticketID == "" {
		// Display status check form
		data := TemplateData{
			Title: "Check Ticket Status",
		}
		
		renderTemplate(w, "status", data)
		return
	}
	
	// Check if ticket exists
	ticket, exists := tickets[ticketID]
	if !exists {
		http.Error(w, "Ticket not found", http.StatusNotFound)
		return
	}
	
	// Create ticket display data
	ticketDisplay := &TicketDisplay{
		ID:                 ticket.ID,
		UserID:             ticket.UserID,
		Date:               ticket.Date,
		DateFormatted:      ticket.Date.Format("January 2, 2006"),
		Status:             ticket.Status,
		CreatedAt:          ticket.CreatedAt,
		CreatedAtFormatted: ticket.CreatedAt.Format("January 2, 2006 15:04:05"),
	}
	
	// Display ticket status
	data := TemplateData{
		Title:  "Ticket Status",
		Ticket: ticketDisplay,
	}
	
	renderTemplate(w, "ticket_details", data)
}

// API endpoint to get all tickets
func handleTicketsAPI(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	
	// Return all tickets as JSON
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(tickets)
}

// API endpoint to check ticket status - vulnerable to SSRF
func handleCheckStatusAPI(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	
	// Get the URL to check from query parameter
	checkURL := r.URL.Query().Get("url")
	if checkURL == "" {
		http.Error(w, "URL parameter is required", http.StatusBadRequest)
		return
	}
	
	// Vulnerable: No URL validation or restriction
	resp, err := http.Get(checkURL)
	if err != nil {
		http.Error(w, "Error checking URL: "+err.Error(), http.StatusInternalServerError)
		return
	}
	defer resp.Body.Close()
	
	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		http.Error(w, "Error reading response: "+err.Error(), http.StatusInternalServerError)
		return
	}
	
	// Return the response
	w.Header().Set("Content-Type", "text/plain")
	w.Write(body)
}

// renderTemplate renders a template with the given data
func renderTemplate(w http.ResponseWriter, tmpl string, data TemplateData) {
	t, ok := templates[tmpl]
	if !ok {
		http.Error(w, "Template not found", http.StatusInternalServerError)
		return
	}
	
	err := t.Execute(w, data)
	if err != nil {
		log.Printf("Error rendering template: %v", err)
		http.Error(w, "Error rendering template", http.StatusInternalServerError)
	}
} 