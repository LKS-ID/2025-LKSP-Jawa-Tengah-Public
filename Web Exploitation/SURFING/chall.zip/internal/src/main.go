package main

import (
	"fmt"
	"log"
	"net/http"
	"os"
	"text/template"
)

// TemplateData holds data for the templates
type TemplateData struct {
	Title string
	Flag  string
}

const (
	port = ":8081"
	flag = "LKS{FAKE_FLAG}"
)

var templates = make(map[string]*template.Template)

func init() {
	// Load templates
	templates["home"] = template.Must(template.ParseFiles("templates/layout.html", "templates/home.html"))
	templates["admin"] = template.Must(template.ParseFiles("templates/layout.html", "templates/admin.html"))
}

func main() {
	// Check if templates directory exists
	if _, err := os.Stat("templates"); os.IsNotExist(err) {
		log.Println("Warning: templates directory not found")
	}

	// Check if static directory exists
	if _, err := os.Stat("static"); os.IsNotExist(err) {
		log.Println("Warning: static directory not found")
	}

	// Serve static files
	http.Handle("/static/", http.StripPrefix("/static/", http.FileServer(http.Dir("static"))))

	// Routes
	http.HandleFunc("/", handleHome)
	http.HandleFunc("/admin", handleAdmin)
	http.HandleFunc("/api/flag", handleFlagAPI)

	log.Printf("Internal service starting on port %s\n", port)
	log.Fatal(http.ListenAndServe(port, nil))
}

func handleHome(w http.ResponseWriter, r *http.Request) {

	data := TemplateData{
		Title: "Internal Admin Service",
	}

	renderTemplate(w, "home", data)
}

func handleAdmin(w http.ResponseWriter, r *http.Request) {


	data := TemplateData{
		Title: "Admin Dashboard",
		Flag:  "FLAG",
	}

	renderTemplate(w, "admin", data)
}

func handleFlagAPI(w http.ResponseWriter, r *http.Request) {

	// Return the flag as JSON
	w.Header().Set("Content-Type", "application/json")
	fmt.Fprintf(w, `{"flag": "%s"}`, flag)
}

// renderTemplate renders a template with the given data
func renderTemplate(w http.ResponseWriter, tmpl string, data TemplateData) {
	t, ok := templates[tmpl]
	if !ok {
		http.Error(w, "Template not found", http.StatusInternalServerError)
		return
	}
	
	err := t.Execute(w, data)
	if err != nil {
		log.Printf("Error rendering template: %v", err)
		http.Error(w, "Error rendering template", http.StatusInternalServerError)
	}
} 